this is my very first time using scripts in shell
