here is my first shell course in alx
